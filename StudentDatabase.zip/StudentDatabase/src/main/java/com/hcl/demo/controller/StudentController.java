package com.hcl.demo.controller;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hcl.demo.dao.StudentService;
import com.hcl.demo.daoimpl.StudentDAOImpl;
import com.hcl.demo.dto.StudAcademicDto;
import com.hcl.demo.model.Academic;
import com.hcl.demo.model.Student;

@Controller
public class StudentController {

	private static final Logger logger = LoggerFactory.getLogger(StudentController.class);
	@Autowired
	StudentService studService;

	@RequestMapping(value = "student/add", method = RequestMethod.GET)
	public String addStudent(Model model) {
		model.addAttribute("studadmdto", new StudAcademicDto());
		logger.info("Returning registration.jsp page");
		return "registration";

	}

	@RequestMapping(value = "student/add.do", method = RequestMethod.POST)
	public String saveStudAcdmDetails(@ModelAttribute("studadmdto") StudAcademicDto studadmdto,
			BindingResult bindingResult, Model model) {
		if (bindingResult.hasErrors()) {
			logger.info("Returning userregn.jsp page");
			return "registration";
		}
		ModelMapper mapper = new ModelMapper();
		Student student = mapper.map(studadmdto, Student.class);
		Academic academic = mapper.map(studadmdto, Academic.class);
		model.addAttribute("studadmdto", studadmdto);
		this.studService.addStudent(student, academic);
		logger.info("Returning success_registered.jsp page");
		return "success_registered";
	}

	@RequestMapping(value = "student/usn", method = RequestMethod.GET)
	public String searchStudUsn(Model model) {
		model.addAttribute("studadmdto", new StudAcademicDto());
		logger.info("Returning studentusn.jsp page");
		
		return "studentusn";

	}
	
	@RequestMapping(value = "student/usn/find.do", method = RequestMethod.POST)
	public String getStudPlace(@ModelAttribute("studadmdto") StudAcademicDto studadmdto, BindingResult bindingResult,
			Model model) {
		if (bindingResult.hasErrors()) {
			logger.info("Returning studentusn.jsp page");
			
			return "studentusn";
		}
		ModelMapper mapper = new ModelMapper();
		Student student = mapper.map(studadmdto, Student.class);

		model.addAttribute("studadmdto", studadmdto);
		String usn1 = student.getUsn();
		model.addAttribute("usn", usn1);
		String place = this.studService.getDetails(usn1);
		model.addAttribute("place", place);
		
		logger.info("Returning success_placeOfStud.jsp page");
	
		return "success_placeOfStud";
	}
	
	
	@RequestMapping(value= "/student/getstudents", method = RequestMethod.GET)
	public String getlink(@ModelAttribute("student") Student student,BindingResult bindingResult, Model model)
	{
		logger.info("Returning link.jsp page");
		return "link";	
	}
	
	
	@RequestMapping(value="/view/{pageid}") 
	public String getAllStudentDetails(@PathVariable int pageid,Model model)
	{
		int total=3;    
        if(pageid==1){}    
        else{    
            pageid=(pageid-1)*total+1;    
        }    
        System.out.println(pageid);  
        List<Student> list=StudentDAOImpl.getAllStudents(pageid,total);    
          model.addAttribute("msg", list);  
        return "studentlistdisplay";    
	}
	@RequestMapping(value="/student/getdata/{usn}", method=RequestMethod.GET)
	@ResponseBody public  String displayDetails(@PathVariable String usn)
	{
		 return usn=this.studService.getDetails(usn);
		
	}
	@RequestMapping(value="/student/list")
@ResponseBody	public List<Student> studentList()
	{
		return this.studService.studentList();
		
	}
	@RequestMapping(value="/student/getAge")
	@ResponseBody	public List<Student> getStudentAge()
		{
			return this.studService.studentAge();
			
		}
}
