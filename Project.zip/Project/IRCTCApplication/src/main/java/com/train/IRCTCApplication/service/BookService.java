package com.train.IRCTCApplication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.train.IRCTCApplication.dto.BookingDto;

@Service
public class BookService {
	
	@Autowired
	RestTemplate restTemplate;
	
	public BookingDto bookingTrainTicket(BookingDto bookingDto) {
		return restTemplate.postForObject("http://localhost:8093/user/book/ticket",bookingDto ,BookingDto.class);
	}
	
	public String cancellingTrainTicket(String bookingId) {
        restTemplate.delete("http://localhost:8093/user/ticket/cancel/{bookingId}",bookingId);
        return "ticket cancelled";
	}

}
