package com.ticket.MovieTicket.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.ticket.MovieTicket.Service.UserService;
import com.ticket.MovieTicket.model.User;

@RestController
public class UserController {
	@Autowired
	UserService userService;

	@PostMapping("/add/user")
	public String addUser(@RequestBody User user) {

		return userService.addUser(user);
	}

}
