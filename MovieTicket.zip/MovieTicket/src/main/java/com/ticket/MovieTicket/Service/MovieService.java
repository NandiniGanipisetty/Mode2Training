package com.ticket.MovieTicket.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ticket.MovieTicket.Dao.MovieDao;
import com.ticket.MovieTicket.Dao.TheaterDao;
import com.ticket.MovieTicket.dto.TheaterDto;
import com.ticket.MovieTicket.model.Movie;
import com.ticket.MovieTicket.model.Show;
import com.ticket.MovieTicket.model.Theater;

@Service
public class MovieService {
	@Autowired
	MovieDao movieDao;
	//adding movie details (moviename,language,release date)
	public String addMovie(Movie movie) {
		movie.setMovieName(movie.getMovieName());
		movie.setLanguage(movie.getLanguage());
		movie.setReleaseDate(movie.getReleaseDate());
		movieDao.save(movie);
		return "movie details added";
	}
//finding the movie details by movie name and date whether the movie is available in the particular date
	public String findShowByMovieName(String movieName, String date) {
		return movieDao.findShowByMovieName(movieName, date);
	}

	
}
