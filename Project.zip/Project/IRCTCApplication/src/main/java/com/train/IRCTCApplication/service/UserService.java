package com.train.IRCTCApplication.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.train.IRCTCApplication.dao.UserDao;
import com.train.IRCTCApplication.dto.LoginDto;
import com.train.IRCTCApplication.exceptionHandler.UserNotFoundException;
import com.train.IRCTCApplication.model.User;

@Service
public class UserService {
	@Autowired
	private UserDao userDao;

	public String addUserDetails(User user) {
		int auto = (int) (Math.random() * 100 + 1);
		String userId = user.getUserName() + auto;
		user.setUserID(userId);
		userDao.save(user);
		return "User details added successfully...!!";
	}

	public Optional<User> loginUser(LoginDto loginDto, String userId) {

		Optional<User> user = userDao.findById(userId);
		/*
		 * System.out.println(loginDto.getUserName());
		 * System.out.println(loginDto.getPassword());
		 * System.out.println(user.getPassword());
		 * System.out.println(user.getUserName());
		 */
		if (!user.isPresent()) {
			throw new UserNotFoundException(userId +" not yet registered! please register");
		} else
			return user;

	}

}
