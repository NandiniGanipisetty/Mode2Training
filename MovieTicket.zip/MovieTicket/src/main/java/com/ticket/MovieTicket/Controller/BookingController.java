package com.ticket.MovieTicket.Controller;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.ticket.MovieTicket.Service.BookingService;
import com.ticket.MovieTicket.dto.BookingDto;
import com.ticket.MovieTicket.model.Booking;

@RestController
public class BookingController {
	@Autowired
	BookingService bookingService;

		@PostMapping("/add/savebookingdetails")
	public Booking bookShow(@RequestParam(value="movieName") String movieName,@RequestParam(value="theaterId") String theaterId,@RequestParam(value="showTime") String showTime,
	@RequestParam(value="userId") String userId)
	{
	 return bookingService.saveBooking(movieName,theaterId,showTime,userId);
	
	}

}
