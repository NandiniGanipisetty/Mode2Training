package com.ticket.MovieTicket.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ticket.MovieTicket.Service.TheaterService;
import com.ticket.MovieTicket.model.Theater;

@RestController
public class TheaterController {
	@Autowired
	TheaterService theaterService;

	@PostMapping("/add/theater")
	public String addTheater(@RequestBody Theater theater) {

		return theaterService.addTheater(theater);
	}

	@GetMapping("/add/theater/getAll")
	public Iterable<Theater> findTheater() {
		// TODO Auto-generated method stub
		Iterable<Theater> list = theaterService.findTheater();
		return list;
	}
}
