package com.bookticket.BookingTrainTicket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookingTrainTicketApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookingTrainTicketApplication.class, args);
	}

}
