package com.ticket.MovieTicket.Service;

import java.util.ArrayList;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ticket.MovieTicket.Dao.ShowDao;
import com.ticket.MovieTicket.Dao.TheaterDao;
import com.ticket.MovieTicket.dto.TheaterDto;
import com.ticket.MovieTicket.model.Show;
import com.ticket.MovieTicket.model.Theater;

@Service
public class TheaterService {
	@Autowired
	TheaterDao theaterDao;
	//@Autowired
	//ShowDao showDao;
	
//Theater theater1=new Theater();
	public String addTheater(Theater theater) {
		theater.setTheaterId(theater.getTheaterId());
		theater.setTheaterName(theater.getTheaterName());
		theater.setPlace(theater.getPlace());
		theaterDao.save(theater);
		return "theater details added";
	}

	public Iterable<Theater> findTheater() {
		// TODO Auto-generated method stub
		Iterable<Theater> list = theaterDao.findAll();
		return list;
	}
	/*
	 * public List<TheaterDto> findTheaterById(String movie){ Theater
	 * theater=theaterDao.findById(theater1.getTheaterId()).orElse(null);
	 * 
	 * 
	 * return null; }
	 */
}
