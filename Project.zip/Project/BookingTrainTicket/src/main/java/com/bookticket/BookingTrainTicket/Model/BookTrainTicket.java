
package com.bookticket.BookingTrainTicket.Model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

@Table(name = "booktrain_ticket")
public class BookTrainTicket {

	@Id
	private String bookingId;

	private String userId;
	private int noOftickets;
	private int trainId;
	private LocalDate date;

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getNoOftickets() {
		return noOftickets;
	}

	public void setNoOftickets(int noOftickets) {
		this.noOftickets = noOftickets;
	}

	public LocalDate getDate() {
		return date;
	}

	public int getTrainId() {
		return trainId;
	}

	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public BookTrainTicket(String bookingId, String userId, int noOftickets, int trainId, LocalDate date) {
		super();
		this.bookingId = bookingId;
		this.userId = userId;
		this.noOftickets = noOftickets;
		this.trainId = trainId;
		this.date = date;
	}

	public BookTrainTicket() { 
		
		super(); // TODO Auto-generateconstructor stub
		}

}
