package com.springmicroservice.SpringMicroServices.Controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.springmicroservice.SpringMicroServices.Dto.CustomerDto;
import com.springmicroservice.SpringMicroServices.Dto.TheaterDto;
import com.springmicroservice.SpringMicroServices.Service.MicroService;

@RestController
public class MicroServiceController {
	@Autowired
	MicroService microService;
	@RequestMapping(value = "/suggest/User",method=RequestMethod.GET)
	public List<TheaterDto> suggestUser() {
		return microService.suggestUser();
	}
}
