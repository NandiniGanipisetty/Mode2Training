package com.train.IRCTCApplication.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.train.IRCTCApplication.dto.PassengerDetails;
import com.train.IRCTCApplication.service.PassengerService;

@RestController
public class PassengerController {

	@Autowired
	PassengerService passengerService;
	
	 @PostMapping(value="/user/add/passenger/{bookingId}") 
	 public List<PassengerDetails> addPassengerDetails(@RequestBody PassengerDetails[] passenger,@PathVariable("bookingId") String bookingId) {
		 return passengerService.addPassengerDetails(bookingId, passenger);
	 }
	 
	 @DeleteMapping(value = "user/ticket/cancelByPnr/{PNR}")
		public String cancellingTrainTicketByPnr(@PathVariable ("PNR") String PNR) {
			passengerService.cancellingTrainTicketByPnr(PNR);
			return "ticket cancelled";
		}
}
