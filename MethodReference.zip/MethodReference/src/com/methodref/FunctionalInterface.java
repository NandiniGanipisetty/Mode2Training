package com.methodref;

public interface FunctionalInterface {
public  int add(int a,int b);
}
