package com.searchTrain.searchTrain.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.searchTrain.searchTrain.model.Passenger;

@Repository
public interface PassengerDao extends CrudRepository<Passenger,String> {
	@Query(value="select  booking_id,no_oftickets,user_id from booktrain_ticket full join  user  on user_id=?1",nativeQuery=true)
public List<Passenger> passengerDetails(String userId);
}
