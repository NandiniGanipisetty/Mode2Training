package com.methodref;

import java.util.Arrays;
import java.util.List;
import java.util.function.BiFunction;
import java.util.stream.Stream;

public class MethodRefMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BiFunction<Integer, Integer, Integer> adder = Calculator::add;
		int result = adder.apply(10, 20);
		System.out.println(result);
		List<Integer> list = Arrays.asList(2, 4, 6, 8, 1, 10, 2);

		// Using peek with count(), which
		// is a terminal operation
		list.stream().peek(System.out::print).sorted();
		// System.out.println(list);

		// List<String> list = Arrays.asList("5.6", "7.4", "4",
		// "1", "2.3");

		// Using Stream flatMap(Function Mapper)
		list.stream().distinct().flatMap(num -> Stream.of(num)).forEach(System.out::println);
		Integer var = list.stream().min(Integer::compare).get();
		Integer var1 = list.stream().max(Integer::compare).get();
		System.out.println("maximum element is:" + var1);
		System.out.println("Minimum element is:" + var);
		int sum = list.stream().reduce(0, (element1, element2) -> element1 + element2);

		// Displaying sum of all elements
		System.out.println("The sum of all elements is " + sum);
		Stream<String> stream = Stream.of("Geeks", "FOr", "GEEKSQUIZ", "GeeksForGeeks");

		// Check if Character at 1st index is
		// UpperCase in any string or not using
		// Stream anyMatch(Predicate predicate)
		boolean answer = stream.anyMatch(str -> Character.isLowerCase((str.charAt(0))));

		// Displaying the result
		System.out.println(answer);
		Stream<Integer> stream1 = Stream.of(5, 6, 7, 8, 9, 10);

		// Using Stream toArray()
		Object[] arr = stream1.toArray();

		// Displaying the elements in array arr
		System.out.println(Arrays.toString(arr));

	}

}
