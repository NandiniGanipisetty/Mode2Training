package com.searchTrain.searchTrain.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.searchTrain.searchTrain.dao.BookTrainTicketDao;
import com.searchTrain.searchTrain.model.BookTrainTicket;
@Service
public class BookTrainTicketService {
	@Autowired
	private BookTrainTicketDao bookTrainTicketDao;
	//@Autowired	private SearchTrainDao searchTrainDao;
	public BookTrainTicket bookTrainTicket(BookTrainTicket bookTrainTicket) {
		//SearchTrain searchTrain=new SearchTrain();
		//List<SearchTrain> list=searchTrainDao.findById(noOftickets);
		int auto = (int) (Math.random() * 100 + 1);
		String bookingId = bookTrainTicket.getFromPlace() + auto;
		bookTrainTicket.setBookingId(bookingId);
		return  bookTrainTicketDao.save(bookTrainTicket);	
	}

	public BookTrainTicket findNoOfTickets(String bookingId, String userId) {
		BookTrainTicket bookTrainTicketDetails = bookTrainTicketDao.findNoOfTickets(bookingId, userId);
		return bookTrainTicketDetails;
	}
	public List<BookTrainTicket> findNoOfTicketsByUserId(String userId) {
	List<BookTrainTicket> bookTrainTicketDetails = bookTrainTicketDao.findNoOfTicketsByUserId(userId);
		return bookTrainTicketDetails;
		
	}
	/*
	 * public String bookTickets(BookTrainTicket bookTrainTicket2) { BookTrainTicket
	 * bookTrainTicket=new BookTrainTicket();
	 *  int noOfTickets=bookTrainTicket.getNoOftickets(); SearchTrain
	 * searchTrain=searchTrainDao.findById(bookTrainTicket.getNoOftickets()).orElse(
	 * null); if(bookTrainTicket2.getNoOftickets()<=noOfTickets) {
	 * noOfTickets-=bookTrainTicket2.getNoOftickets();
	 * searchTrainDao.save(searchTrain); bookTrainTicketDao.save(bookTrainTicket); }
	 * return "booked"; }
	 */
}
