package com.springmicroservice.SpringMicroServices.Dto;

import java.time.LocalDate;

public class TheaterDto {
	private String theaterId;
	private String showId;
		private String theaterName;
	private String Place;
	private String mrngShow;
	private String noonShow;
	private String evngShow;
	private LocalDate date;

	public String getMrngShow() {
		return mrngShow;
	}

	public void setMrngShow(String mrngShow) {
		this.mrngShow = mrngShow;
	}

	public String getNoonShow() {
		return noonShow;
	}

	public void setNoonShow(String noonShow) {
		this.noonShow = noonShow;
	}

	public String getEvngShow() {
		return evngShow;
	}

	
	public void setEvngShow(String evngShow) {
		this.evngShow = evngShow;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

		public String getTheaterName() {
		return theaterName;
	}

	public void setTheaterName(String theaterName) {
		this.theaterName = theaterName;
	}

	public String getPlace() {
		return Place;
	}

	public void setPlace(String place) {
		Place = place;
	}
	public String getTheaterId() {
		return theaterId;
	}

	public void setTheaterId(String theaterId) {
		this.theaterId = theaterId;
	}

	public String getShowId() {
		return showId;
	}

	public void setShowId(String showId) {
		this.showId = showId;
	}




}
