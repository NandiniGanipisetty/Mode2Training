package com.searchTrain.searchTrain.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.searchTrain.searchTrain.model.*;
@Repository
public interface BookTrainTicketDao  extends CrudRepository<BookTrainTicket,String>{
	@Query(value="select * from booktrain_ticket where booking_id=?1 and  user_id=?2",nativeQuery=true)
	public BookTrainTicket findNoOfTickets(String bookingId,String userId);
	@Query(value="select *from user full join  booktrain_ticket on user_id=?1"  ,nativeQuery=true)
	
 List<BookTrainTicket> findNoOfTicketsByUserId(String userId);
	/*
	 * //SELECT d.booking_id, e.user_name, FROM user d INNER JOIN booktrain_ticket e
	 * ON d.userid = e.user_id;
	 * /@Query(value="select *from booktrain_ticket full join  user on user_id=?1,user_name=?2"  ,nativeQuery=true)
/
	 * @Query(
	 * value="select booktrain_ticket.booking_id,booktrain_ticket.from_place,booktrain_ticket.to_place,booktrain_ticket.no_ofseats"
	 * ) List<BookTrainTicket> findNoOfTicketsByUserIdAndBookingId(String
	 * userId,String bookingId);
	 * //@Query(value="select booktrain_ticket.booking_id,booktrain_ticket.from_place,booktrain_ticket.to_place,booktrain_ticket.date,booktrain_ticket.user_id from booktrain_ticket inner join user on booktrain_ticket.user_id=user.userid;",nativeQuery=true)
	 *
	 */
}
