package com.ticket.MovieTicket.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.ticket.MovieTicket.Dao.UserDao;
import com.ticket.MovieTicket.model.User;

@Service
public class UserService {
	@Autowired
	UserDao userDao;
	//adding user details
	public String addUser(@RequestBody User user) {
		user.setUserId(user.getUserId());
		user.setUserName(user.getUserName());
		user.setPhoneNo(user.getPhoneNo());
		user.setEmailId(user.getEmailId());
		userDao.save(user);

		return "user details added successfully";
	}
}
