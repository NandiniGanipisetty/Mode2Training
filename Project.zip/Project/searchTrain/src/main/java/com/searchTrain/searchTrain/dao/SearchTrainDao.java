package com.searchTrain.searchTrain.dao;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.searchTrain.searchTrain.model.SearchTrain;


@Repository
public interface SearchTrainDao extends CrudRepository<SearchTrain, Integer> {
	@Query(value = "select * from train_details where from_place=?1 and to_place=?2 and date=?3 ", nativeQuery = true)
	public Optional<SearchTrain> findTrain(String fromPlace, String toPlace, LocalDate date);

	

}
