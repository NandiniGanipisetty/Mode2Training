package com.bank;
import java.lang.annotation.*;
@Repeatable(Students.class)
@interface Student {
int id();
String name();
}
@Retention(RetentionPolicy.RUNTIME)  

@interface Students{
	Student[] value();
}
@Student(id = 01, name = "nandu")
@Student(id = 02, name = "nandini")

public class StudentInfo {
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		Student[] s =  StudentInfo.class.getAnnotationsByType(Student.class);
		for(Student stud:s){
		System.out.println(stud.id()+" "+stud.name());

		}
	}

}
