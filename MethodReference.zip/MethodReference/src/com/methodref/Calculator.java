package com.methodref;

public class Calculator {
	public static int add(int a, int b) {
		// TODO Auto-generated method stub
		return a + b;
	}
}
