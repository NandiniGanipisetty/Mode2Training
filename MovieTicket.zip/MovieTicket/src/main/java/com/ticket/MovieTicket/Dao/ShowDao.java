package com.ticket.MovieTicket.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ticket.MovieTicket.model.Show;

@Repository
public interface ShowDao extends CrudRepository<Show, String>{
	@Query(value ="select * from showmovie  where ((mrng_show=?1) or (noon_show=?1) or (evng_show=?1))",nativeQuery=true)
	//select * from showmovie m where ((mrng_show="sahho") or (noon_show="sahho") or (evng_show="sahho") and m.date=2019-09-11)

	public List<Show> getMovieTime(String movieName);
}
