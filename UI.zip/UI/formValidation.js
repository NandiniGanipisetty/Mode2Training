function formValidation()
{
	var uName=document.register.name.value;
	var password1=document.register.p1.value;
	var password2=document.register.p2.value;
	var uAge=document.register.age.value;
	var genderMale = document.getElementById("register_gendermale").checked;
	var genderFemale = document.getElementById("register_genderfemale").checked;
	var uAge=document.register.age.value;
 if (uName== "") {
  
    document.getElementById('uName').innerHTML.value="";
    alert( "Username is required");
    uName.focus();
    return false;
  }
  
}