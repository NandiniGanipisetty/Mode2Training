package com.web.service;

public class CalculatorService {
	public int addition(int a, int b) {
		return a + b;
	}
	public double multiplication(double a,double b)
	{
		return a*b;
	}
	public int subtraction(int a,int b)
	{
		return a-b;
	}
	public float division(float a,float b)
	{
		return a/b;
	}
}
