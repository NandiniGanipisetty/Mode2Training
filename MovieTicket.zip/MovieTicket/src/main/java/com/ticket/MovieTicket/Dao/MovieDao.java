package com.ticket.MovieTicket.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.ticket.MovieTicket.model.Movie;
import com.ticket.MovieTicket.model.Show;

@Repository
public interface MovieDao extends CrudRepository<Movie, String> {
	@Query(value = "select * from theater  t where t.theater_id in(select   s.theater_id from showmovie  s where ((mrng_show=?1) or (noon_show=?1) or (evng_show=?1) and s.date= ?2)) ", nativeQuery = true)
	public String findShowByMovieName(String movieName, String date);
	
	
}
