package com.web.service;

public class CalculatorServicePortTypeProxy implements com.web.service.CalculatorServicePortType {
  private String _endpoint = null;
  private com.web.service.CalculatorServicePortType calculatorServicePortType = null;
  
  public CalculatorServicePortTypeProxy() {
    _initCalculatorServicePortTypeProxy();
  }
  
  public CalculatorServicePortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initCalculatorServicePortTypeProxy();
  }
  
  private void _initCalculatorServicePortTypeProxy() {
    try {
      calculatorServicePortType = (new com.web.service.CalculatorServiceLocator()).getCalculatorServiceHttpSoap11Endpoint();
      if (calculatorServicePortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)calculatorServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)calculatorServicePortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (calculatorServicePortType != null)
      ((javax.xml.rpc.Stub)calculatorServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.web.service.CalculatorServicePortType getCalculatorServicePortType() {
    if (calculatorServicePortType == null)
      _initCalculatorServicePortTypeProxy();
    return calculatorServicePortType;
  }
  
  public int addition(int a, int b) throws java.rmi.RemoteException{
    if (calculatorServicePortType == null)
      _initCalculatorServicePortTypeProxy();
    return calculatorServicePortType.addition(a, b);
  }
  
  
}