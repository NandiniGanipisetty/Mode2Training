package com.searchTrain.searchTrain.controller;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.searchTrain.searchTrain.model.SearchTrain;
import com.searchTrain.searchTrain.service.SearchTrainService;


@RestController
public class SearchTrainController {
	@Autowired
	SearchTrainService searchingTrainService;

	@GetMapping(value = "search/train")
	public Optional<SearchTrain> findTrain(@RequestParam("fromPlace") String fromPlace,
			@RequestParam("toPlace") String toPlace,
			@RequestParam("date") @DateTimeFormat(iso = ISO.DATE) LocalDate date) {
		return searchingTrainService.findTrain(fromPlace, toPlace, date);
	}

	@GetMapping(value = "search/get/train/{trainId}")
	public Optional<SearchTrain> findByTrainId(@PathVariable("trainId") Integer trainId) {
		return searchingTrainService.findByTrainId(trainId);

	}

}
