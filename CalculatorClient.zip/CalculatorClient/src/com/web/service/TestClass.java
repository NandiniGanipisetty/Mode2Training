package com.web.service;

import java.rmi.RemoteException;

public class TestClass {
	public static void main(String args[]) {
		try {
			CalculatorServiceStub stub = new CalculatorServiceStub();
			CalculatorServiceStub.Addition params = new CalculatorServiceStub.Addition();
			params.setA(40);
			params.setB(50);
			CalculatorServiceStub.AdditionResponse response = stub.addition(params);
			int result = response.get_return();
			System.out.println("addition result is:" +result);
			CalculatorServiceStub.Subtraction param=new CalculatorServiceStub.Subtraction();
			param.setA(20);
			param.setB(10);
			CalculatorServiceStub.SubtractionResponse response1=stub.subtraction(param);
			int subtract_res=response1.get_return();
			System.out.println("subtraction result is:" +subtract_res);
			CalculatorServiceStub.Multiplication multiplication=new CalculatorServiceStub.Multiplication();
			multiplication.setA(12);
			multiplication.setB(4);
			CalculatorServiceStub.MultiplicationResponse response2=stub.multiplication(multiplication);
			double multiply_res=response2.get_return();
			System.out.println("multiplication result is:"+multiply_res);
			CalculatorServiceStub.Division division=new CalculatorServiceStub.Division();
			division.setA(12);
			division.setB(4);
			CalculatorServiceStub.DivisionResponse response3=stub.division(division);
			double division_res=response3.get_return();
			System.out.println("division result is:"+division_res);
			
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}
}