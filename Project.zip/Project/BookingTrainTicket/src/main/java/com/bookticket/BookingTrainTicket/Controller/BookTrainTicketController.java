package com.bookticket.BookingTrainTicket.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bookticket.BookingTrainTicket.Dto.BookingDto;
import com.bookticket.BookingTrainTicket.Model.BookTrainTicket;
import com.bookticket.BookingTrainTicket.Service.BookTrainTicketService;

@RestController
public class BookTrainTicketController {
	@Autowired
	BookTrainTicketService bookTrainTicketService;

	@PostMapping(value = "user/book/ticket")
	public BookingDto bookingTrainTicket(@RequestBody BookTrainTicket bookTrainTicket) {
		 return bookTrainTicketService.bookingTrainTicket(bookTrainTicket);
		 
	}

	@DeleteMapping(value = "user/ticket/cancel/{bookingId}")
	public String cancellingTrainTicket(@PathVariable ("bookingId") String bookingId) {
		 bookTrainTicketService.cancellingTrainTicket(bookingId);
		 return "ticket cancelled successfully";
	}
		
	

}
