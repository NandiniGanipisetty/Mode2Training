package com.bank;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
@Repeatable(Customers.class)

@interface Customer1{
	String name();
	String age();
	String phoneno();
}
@Retention(RetentionPolicy.RUNTIME)  

@interface Customers{
	Customer1[] value();
}
@Customer1(age = "21", name = "nandu", phoneno = "1234567890")
@Customer1(age = "22", name = "nandini", phoneno = "0987665432")

public class Customer {
	private String accno;
	private String name;
	private long balance;
	private String phoneno;
	private int age;
	Scanner sc = new Scanner(System.in);
	List<String> a1 = new ArrayList<String>();
	List<String> a2 = new ArrayList<String>();
	List<String> a = new ArrayList<String>();
	List<String> a3 = new ArrayList<String>();
	List<String> a4 = new ArrayList<String>();
	List<Integer> a5 = new ArrayList<Integer>();
	List<Integer> a6 = new ArrayList<Integer>();
	Customer1[] cust=Customer.class.getAnnotationsByType(Customer1.class);

	// method to open an account
	void openAccount() {
		System.out.print("Enter Account No: ");
		accno = sc.next();
		a.add(accno);
		a1 = a.stream().map(s1 -> ("SBI" + s1)).collect(Collectors.toList());
		System.out.println(a1);
		a2 = a1.stream().distinct().filter(i -> i.length() > 8).collect(Collectors.toList());
		// a3 = a1.stream().distinct().filter(i ->
		// i.).collect(Collectors.toList());

		//System.out.println("Valid account numbers:" + a2);
		// while (accno.length() < 8) {
		// System.out.println("please enter an account number with 8 didgits");
		// accno = sc.next();

		// }

		System.out.print("Enter Name: ");
		for(Customer1 customer:cust)
		{
			System.out.println(customer.name());
		}
		
		System.out.print("Enter Balance: ");
		balance = sc.nextLong();
		System.out.println("enter the phone number");
		for(Customer1 customer:cust)
		{
			System.out.println(customer.phoneno());

		}
		System.out.println("enter age:");
		for(Customer1 customer:cust)
		{
			System.out.println(customer.age());
			a5.add(age);
			//a4 = a3.stream().distinct().filter(i -> i.valueOf(i)).collect(Collectors.toList());

		}

		
	}

	// method to display account details
	void showAccount() {
		System.out.println(accno + "," + name + "," + balance);
	}

	// method to deposit money
	void deposit() {
		long amt;
		System.out.println("Enter Amount U Want to Deposit : ");
		amt = sc.nextLong();
		balance = balance + amt;
		System.out.println(balance);

	}

	// method to withdraw money
	void withdrawal() {
		long amt;
		System.out.println("Enter Amount U Want to withdraw : ");
		amt = sc.nextLong();
		if (balance >= amt) {
			balance = balance - amt;
			System.out.println(balance);
		} else {
			System.out.println("Less Balance..Transaction Failed..");
		}
	}

	/*
	 * void miniStatement() { List<Long> rem = new ArrayList<Long>();
	 * c.deposit();
	 * 
	 * }
	 */
	// method to search an account number
	boolean search(String acn) {
		if (accno.equals(acn)) {
			showAccount();
			return (true);
		}
		return (false);
	}
}
