package com.hcl.demo.dao;
import java.util.List;

import com.hcl.demo.model.Academic;
import com.hcl.demo.model.Student;

public interface StudentService {
	
	
	public void addStudent(Student student, Academic acadmic);
	public String getDetails(String usn);
	public List<Student> studentList();
	public List<Student> studentAge();
	public List<Student> listStudent(int pageno,int pagesize);
}
