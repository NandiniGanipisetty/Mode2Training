package com.ticket.MovieTicket.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.ticket.MovieTicket.Service.ShowService;
import com.ticket.MovieTicket.dto.TheaterDto;
import com.ticket.MovieTicket.model.Show;

@RestController
public class ShowController {
	@Autowired
	ShowService showService;

	@PostMapping("/add/show")
	public String showTime(@RequestBody Show show) {

		return showService.showTime(show);
	}
	@GetMapping(value="add/get/{movieName}")
	public List<TheaterDto> getMovieTime(@PathVariable("movieName")String movieName)
	{
		return showService.getMovieTime(movieName);
		
	}

}
